// Aquí puedes editar fácilmente las categorías y productos.
const DATA = {
  "Proteínas": ["Pollo", "Pechuga", "Carne molida", "Res", "Cerdo", "Pescado", "Mariscos", "Huevos"],
  "Verduras": ["Tomate", "Cebolla", "Ajo", "Lechuga", "Zanahoria", "Papas"],
  "Frutas": ["Manzana", "Banana", "Naranja", "Papaya", "Uvas"],
  "Lácteos": ["Leche", "Yogurt", "Queso", "Mantequilla", "Jamón"],
  "Enlatados": ["Atún", "Sardinas", "Habichuelas", "Maíz dulce"],
  "Secos": ["Arroz", "Pasta", "Frijoles", "Harina", "Azúcar", "Café"],
  "Condimentos": ["Aceite", "Vinagre", "Salsas", "Cubitos", "Especias"],
  "Snacks": ["Papas fritas", "Chocolates", "Galletas"],
  "Aseo Personal": ["Pasta dental", "Jabón", "Shampoo", "Desodorante", "Papel higiénico"],
  "Limpieza Hogar": ["Jabón platos", "Cloro", "Desinfectante", "Aromatizante", "Bolsas"],
  "Herramientas": ["Escoba", "Trapeador", "Recogedor", "Fibra"],
  "Lavandería": ["Detergente", "Suavizante", "Quitamanchas"],
  "Bebés": ["Pañales", "Toallitas", "Fórmula"],
  "Mascotas": ["Alimento", "Shampoo"]
};
