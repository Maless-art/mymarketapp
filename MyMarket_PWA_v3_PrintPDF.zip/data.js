// Aquí puedes editar fácilmente las categorías y productos.
const DATA = {
  "Proteínas": ["Muslo encuentro", "Muslo", "Pechuga", "Alitas", "Carne", "Puerco", "Pescado", "Huevos"],
  "Verduras": ["Tomate", "Cebolla", "Ajo", "Lechuga", "Zanahoria", "Pepino", "Habichuelas", "Ají",    
  "Gengibre", "Ñame", "Yuca", "Papas"],
  "Frutas": ["Manzana", "Guineo", "Naranja", "Papaya", "Uvas", "Piña", "Plátano verde"],
  "Lácteos": ["Leche", "Yogurt", "Queso Amarillo", "Queso Blanco", "Mantequilla"],
  "Embutidos": ["Jamón", "Salchichas", "Chorizos", "Mortadela"],
  "Enlatados": ["Tuna", "Sardina", "Campbels", "Vegetales", "Hongos", "Maíz dulce"],
  "Secos": ["Arroz", "Pasta", "Frijoles", "Lentejas", "Porotos", "Habas", "Arbejas", "Sal", "Harina", "Azúcar", "Café"],
  "Condimentos": ["Aceite", "Vinagre", "Salsa de Tomate", "Pimienta", "Especias", "Curry", "Caldo Rika", "Laurel", "Ajo Molido", "Sazonador"],
  "Snacks": ["Papas fritas", "Chocolates", "Galletas", "Cheetos"],
  "Aseo Personal": ["Pasta dental", "Jabón de Baño", "Jabón de Manos", "Enjuague Bucal", "Shampoo", "Desodorante", "Gel", "Crema Corporal", "Papel higiénico", "Toallas Sanitarias"],
  "Limpieza Hogar": ["Lava platos", "Desinfectante", "Aromatizante", "Bolsas Negras", "Bolsas blancas", "Papel Toalla"],
  "Herramientas": ["Escoba", "Trapeador", "Recogedor", "Esponja de Fregar"],
  "Lavandería": ["Detergente", "Cloro", "Suavizante", "Quitamanchas"],
  "Bebés": ["Pañales", "Toallitas", "Fórmula", "Jabón", "Shampoo"],
  "Mascotas": ["Alimento", "Shampoo", "Carne Molida", "Huesos", "Sobres Blandos"],
  "Bebidas": ["Jugos", "Sodas", "Agua", "Cervezas", "Licor"]
};
