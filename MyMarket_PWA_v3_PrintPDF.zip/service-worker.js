const CACHE_NAME = "mymarket-cache-v4print";
const URLS_TO_CACHE = [
  "./",
  "./index.html",
  "./manifest.json",
  "./data.js",
  "./icon-180.png",
  "./icon-192.png",
  "./icon-512.png",
  "./click.wav"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(URLS_TO_CACHE))
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    )
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.mode === "navigate") {
    // HTML: SIEMPRE DESDE RED
    event.respondWith(
      fetch(event.request).catch(() => caches.match(event.request))
    );
    return;
  }

  // Assets (js, css, png): cache normal
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
